//
//  Hippo.h
//  Hippo
//
//  Created by Vishal on 07/06/18.
//  Copyright © 2018 Jungleworks. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Hippo.
FOUNDATION_EXPORT double HippoVersionNumber;

//! Project version string for Hippo.
FOUNDATION_EXPORT const unsigned char HippoVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Hippo/PublicHeader.h>


