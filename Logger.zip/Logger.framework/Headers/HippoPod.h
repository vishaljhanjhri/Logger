//
//  HippoPod.h
//  HippoPod
//
//  Created by Vishal on 06/06/18.
//  Copyright © 2018 Jungleworks. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for HippoPod.
FOUNDATION_EXPORT double HippoPodVersionNumber;

//! Project version string for HippoPod.
FOUNDATION_EXPORT const unsigned char HippoPodVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HippoPod/PublicHeader.h>


